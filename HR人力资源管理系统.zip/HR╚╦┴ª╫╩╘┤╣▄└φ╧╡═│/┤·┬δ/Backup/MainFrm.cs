using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ������Դ����ϵͳ
{
	/// <summary>
	/// Form1 ��ժҪ˵����
	/// </summary>
	public class MainFrm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel2;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.MenuItem menuItem12;
		private System.Windows.Forms.MenuItem menuItem13;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem14;
		/// <summary>
		/// ����������������
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MainFrm()
		{
			//
			// Windows ���������֧���������
			//
			InitializeComponent();

			//
			// TODO: �� InitializeComponent ���ú������κι��캯������
			//
		}

		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows ������������ɵĴ���
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainFrm));
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanel2 = new System.Windows.Forms.StatusBarPanel();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuItem11 = new System.Windows.Forms.MenuItem();
			this.menuItem12 = new System.Windows.Forms.MenuItem();
			this.menuItem13 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItem14 = new System.Windows.Forms.MenuItem();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).BeginInit();
			this.SuspendLayout();
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 491);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.statusBarPanel1,
																						  this.statusBarPanel2});
			this.statusBar1.ShowPanels = true;
			this.statusBar1.Size = new System.Drawing.Size(712, 22);
			this.statusBar1.TabIndex = 1;
			// 
			// statusBarPanel1
			// 
			this.statusBarPanel1.MinWidth = 200;
			this.statusBarPanel1.Text = " ���ݿ⿪�����䰸������  �廪��ѧ������  �û���½���ܺ�Ȩ�޹������ܲο�������ʵ��";
			this.statusBarPanel1.Width = 500;
			// 
			// statusBarPanel2
			// 
			this.statusBarPanel2.Width = 200;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItem2,
																					  this.menuItem3,
																					  this.menuItem4,
																					  this.menuItem14});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem5,
																					  this.menuItem6});
			this.menuItem1.Text = "�������ƹ���(&X)";
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 0;
			this.menuItem5.Text = "�������ü�����(&Y)";
			this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 1;
			this.menuItem6.Text = "������ϸ��Ϣ(&Z)";
			this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 1;
			this.menuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem7,
																					  this.menuItem8});
			this.menuItem2.Text = "ְԱ��Ϣ����(&Y)";
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 0;
			this.menuItem7.Text = "ְԱ��Ϣά��(&Y)";
			this.menuItem7.Click += new System.EventHandler(this.menuItem7_Click);
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 1;
			this.menuItem8.Text = "ְԱ��Ϣ��ѯ(&Z)";
			this.menuItem8.Click += new System.EventHandler(this.menuItem8_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 2;
			this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem9,
																					  this.menuItem10,
																					  this.menuItem11,
																					  this.menuItem12,
																					  this.menuItem13});
			this.menuItem3.Text = "н�ʸ�������(&Z)";
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 0;
			this.menuItem9.Text = "���¹��ʹ���(&V)";
			this.menuItem9.Click += new System.EventHandler(this.menuItem9_Click);
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 1;
			this.menuItem10.Text = "��������˰��(&W)";
			this.menuItem10.Click += new System.EventHandler(this.menuItem10_Click);
			// 
			// menuItem11
			// 
			this.menuItem11.Index = 2;
			this.menuItem11.Text = "���ʷ�����ʷ(&X)";
			this.menuItem11.Click += new System.EventHandler(this.menuItem11_Click);
			// 
			// menuItem12
			// 
			this.menuItem12.Index = 3;
			this.menuItem12.Text = "ְԱ��������(&Y)";
			this.menuItem12.Click += new System.EventHandler(this.menuItem12_Click);
			// 
			// menuItem13
			// 
			this.menuItem13.Index = 4;
			this.menuItem13.Text = "ְԱ�ͷ�����(&Z)";
			this.menuItem13.Click += new System.EventHandler(this.menuItem13_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 3;
			this.menuItem4.Text = "�˳�ϵͳ(&Q)";
			this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
			// 
			// menuItem14
			// 
			this.menuItem14.Index = 4;
			this.menuItem14.Text = "";
			// 
			// MainFrm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.ClientSize = new System.Drawing.Size(712, 513);
			this.Controls.Add(this.statusBar1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.IsMdiContainer = true;
			this.Menu = this.mainMenu1;
			this.Name = "MainFrm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "������Դ����ϵͳ";
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Ӧ�ó��������ڵ㡣
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainFrm());
		}

		//----------------------��ʾ�������ñ����-----------------------------
		private void menuItem5_Click(object sender, System.EventArgs e)
		{
			//ͨ���������Ʋ�ѯ�ô����Ƿ��Ѿ����ڣ����������ʾ��������´���һ��
			if (this.checkChildFrmExist("SetOrgInfo") == true)
			{
				return;
			}
			SetOrgInfo newFrm = new SetOrgInfo();
			newFrm.MdiParent = this;
			newFrm.Show();			
		}

		//----------------------��ʾ������ϸ��Ϣ-----------------------------
		private void menuItem6_Click(object sender, System.EventArgs e)
		{
			if (this.checkChildFrmExist("OrgInfo") == true)
			{
				return;
			}
			OrgInfo newFrm = new OrgInfo();
			newFrm.MdiParent = this;
			newFrm.Show();			
		}

		//----------------------��ʾְԱ��Ϣά������-----------------------------
		private void menuItem7_Click(object sender, System.EventArgs e)
		{
			if (this.checkChildFrmExist("AmendStafferInfo") == true)
			{
				return;
			}
			AmendStafferInfo newFrm = new AmendStafferInfo();
			newFrm.MdiParent = this;
			newFrm.Show();				
		}

		//----------------------��ʾְԱ��Ϣ��ѯ����-----------------------------
		private void menuItem8_Click(object sender, System.EventArgs e)
		{
			if (this.checkChildFrmExist("LookupStafferInfo") == true)
			{
				return;
			}
			LookupStafferInfo newFrm = new LookupStafferInfo();
			newFrm.MdiParent = this;
			newFrm.Show();	
		}
        
		//----------------------��ʾ���¹��ʹ�������-----------------------------
		private void menuItem9_Click(object sender, System.EventArgs e)
		{
			if (this.checkChildFrmExist("SalaryManage") == true)
			{
				return;
			}
			SalaryManage newFrm = new SalaryManage();
			newFrm.MdiParent = this;
			newFrm.Show();	
		}

		//----------------------��ʾ��������˰�ʴ���----------------------------
		private void menuItem10_Click(object sender, System.EventArgs e)
		{
			if (this.checkChildFrmExist("IncomeTax") == true)
			{
				return;
			}
			IncomeTax newFrm = new IncomeTax();
			newFrm.MdiParent = this;
			newFrm.Show();	
		}

        //----------------------��ʾ���ʷ��ż�¼����-----------------------------
		private void menuItem11_Click(object sender, System.EventArgs e)
		{
			if (this.checkChildFrmExist("PayoffHistory") == true)
			{
				return;
			}
			PayoffHistory newFrm = new PayoffHistory();
			newFrm.MdiParent = this;
			newFrm.Show();	
		}

        //----------------------��ʾְԱ������-----------------------------
		private void menuItem12_Click(object sender, System.EventArgs e)
		{
			if (this.checkChildFrmExist("HortationManage") == true)
			{
				return;
			}
			HortationManage newFrm = new HortationManage();
			newFrm.MdiParent = this;
			newFrm.Show();	
		}

        //----------------------��ʾְԱ�ͷ���-----------------------------
		private void menuItem13_Click(object sender, System.EventArgs e)
		{
			if (this.checkChildFrmExist("PunishmentManage") == true)
			{
				return;
			}
			PunishmentManage newFrm = new PunishmentManage();
			newFrm.MdiParent = this;
			newFrm.Show();	
		}

		 //----------------------��ѯMDI�Ӵ����Ƿ����-----------------------------
		private bool checkChildFrmExist(string childFrmName)
		{
			foreach(Form childFrm in this.MdiChildren)
			{
				if(childFrm.Name == childFrmName) //���Ӵ����Name�����жϣ����������������
				{
					if(childFrm.WindowState == FormWindowState.Minimized)
						childFrm.WindowState = FormWindowState.Normal;
					childFrm.Activate();
					return true;
				}
			}
			return false;
		}

         //----------------------�˳�����-----------------------------
		private void menuItem4_Click(object sender, System.EventArgs e)
		{
            if (MessageBox.Show("ȷʵҪ�˳�ϵͳ��?","ѯ��",MessageBoxButtons.YesNo) == DialogResult.Yes)

			{
				this.Close();
			}
		
		}

	

		
	}
}
